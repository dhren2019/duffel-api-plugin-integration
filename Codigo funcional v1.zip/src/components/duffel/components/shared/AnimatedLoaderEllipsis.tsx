import * as React from "react";

export const AnimatedLoaderEllipsis: React.FC = () => (
  <span className="textual-loading-indicator" aria-hidden="true" />
);
