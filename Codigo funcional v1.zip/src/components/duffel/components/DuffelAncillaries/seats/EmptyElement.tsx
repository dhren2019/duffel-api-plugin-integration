import * as React from "react";

export const EmptyElement: React.FC = () => (
  <div className="map-element map-element--empty" />
);
